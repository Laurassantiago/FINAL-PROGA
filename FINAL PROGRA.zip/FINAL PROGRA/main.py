import sqlite3
import bcrypt
from menu_despues_sesion import mostrar_menu_despues_sesion, crear_contraseña, ver_contraseñas

#SEGURIDAD
def hash_password(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

def check_password(hashed_password, user_password):
    return bcrypt.checkpw(user_password.encode('utf-8'), hashed_password)

#Base de datos de usuarios
def crear_tabla_usuarios(conexion):
    cursor = conexion.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS usuarios (
                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                      nombre_usuario TEXT NOT NULL,
                      correo TEXT NOT NULL UNIQUE,
                      contraseña TEXT NOT NULL
                      )''')
    conexion.commit()

#Funcion para mostrar el menu
def mostrar_menu():
    print("Hola, ¿qué desea realizar?")
    print("1. Crear un nuevo usuario")
    print("2. Iniciar sesión")
    print("3. Olvide mi contraseña")
    print("4. Salir")

# Lista para almacenar los nombres de usuario
nombres_usuarios = []

#Crear usuario
def crear_usuario(conexion):
    print("Ingrese el nombre de usuario:")
    nombre_usuario = input().capitalize()
    if nombre_usuario in nombres_usuarios:
        print("Error: El nombre de usuario ya está en uso. Por favor, elija otro.")
        return

    print("Ingrese su correo electrónico:")
    correo = input().capitalize()
    print("Ingrese contraseña para LockUp:")
    password = input()

    cursor = conexion.cursor()
    try:
        cursor.execute("SELECT * FROM usuarios WHERE nombre_usuario = ?", (nombre_usuario,))
        usuario = cursor.fetchone()
        if usuario:
            print("Error: El nombre de usuario ya está en uso. Por favor, elija otro.")
        else:
            cursor.execute("INSERT INTO usuarios (nombre_usuario, correo, contraseña) VALUES (?, ?, ?)",
                           (nombre_usuario, correo, hash_password(password)))
            conexion.commit()
            print("Usuario creado exitosamente")

            # Agregar el nombre de usuario a la lista
            nombres_usuarios.append(nombre_usuario)
    except sqlite3.IntegrityError:
        print("Error: El correo electrónico ya está en uso. Por favor, elija otro.")


#Iniciar sesion
def iniciar_sesion(conexion):
    print("Ingrese su nombre de usuario:")
    nombre_usuario = input().capitalize()

    cursor = conexion.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE nombre_usuario = ?", (nombre_usuario,))
    usuario = cursor.fetchone()

    if usuario:
        print("Usuario encontrado. Por favor, ingrese su contraseña:")
        contraseña = input()
        if check_password(usuario[3], contraseña):
            print("¡Inicio de sesión exitoso!")
            # Mostrar menú después de iniciar sesión
            mostrar_menu_despues_sesion()
            opcion = input("Por favor, ingrese el número de la opción deseada: ")
            if opcion == "1":
                crear_contraseña()
            elif opcion == "2":
                ver_contraseñas()
            else:
                print("Opción no válida.")
        else:
            print("Contraseña incorrecta. Por favor, inténtelo de nuevo.")
    else:
        print("Usuario no encontrado. Por favor, regístrese antes de iniciar sesión.")


#Opcion olvide mi contraseña
def olvide_contraseña(conexion):
    print("Ingrese su correo electrónico para restablecer su contraseña:")
    correo = input().capitalize()

    cursor = conexion.cursor()
    cursor.execute("SELECT id FROM usuarios WHERE correo = ?", (correo,))
    usuario = cursor.fetchone()

    if usuario:
        print("Ingrese su nueva contraseña:")
        nueva_contraseña = hash_password(input())
        cursor.execute("UPDATE usuarios SET contraseña = ? WHERE id = ?", (nueva_contraseña, usuario[0]))
        conexion.commit()
        print("Contraseña actualizada con éxito.")
    else:
        print("No se encontró ningún usuario con ese correo electrónico.")

#OPCION DE SALIR
def salir():
    print("¡Hasta luego!")
    exit()


#MENU PRINCIPAL
if __name__ == "__main__":
    conexion = sqlite3.connect("usuarios.db")
    crear_tabla_usuarios(conexion)
    try:
        while True:
            mostrar_menu()
            opcion = input("Por favor, ingrese el número de la opción deseada: ")
            
            if opcion == "1":
                crear_usuario(conexion)
            elif opcion == "2":
                iniciar_sesion(conexion)
            elif opcion == "3":
                olvide_contraseña(conexion)   
            elif opcion == "4":
                salir()
            else:
                print("Opción no válida. Por favor, ingrese un número válido.")
    finally:
        conexion.close()









#Si ya ingreso usuaio poner para que app desea generar contraseña, guardarlo y agregar a la base de datos


#Que falta
#Ver que el codigo este funsionando bien
#Ingresar la opcion de que mande el codigo de verificacion 
#Hacer que al momento que ingrese el usuario, se muestre otro menu para ver las contraselas o crar y de ahi que las guarde en una base de datos, 