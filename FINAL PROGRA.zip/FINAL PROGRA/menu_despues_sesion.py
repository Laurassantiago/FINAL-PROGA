def mostrar_menu_despues_sesion():
    print("¡Bienvenido! ¿Qué desea hacer ahora?")
    print("1. Crear nueva contraseña")
    print("2. Ver contraseñas guardadas")
    print("3. Cerrar sesión")

def crear_contraseña():
    num_caracteres = int(input("Ingresa el número de caracteres que deseas en tu contraseña: "))
    
    if num_caracteres <= 0:
        print("Por favor ingresa un número válido de caracteres.")
        return
    
    palabras = []
    while sum(len(palabra) for palabra in palabras) < num_caracteres:
        palabra = input("Ingresa una palabra para tu contraseña: ")
        palabras.append(palabra)
    
    contraseña = "".join(palabras)[:num_caracteres]
    print("Tu contraseña creada es:", contraseña)
   
    respuesta = input("¿Deseas guardar esta contraseña? (si/no): ").lower()
    if respuesta == "si":
        # Aquí puedes agregar la lógica para guardar la contraseña en alguna parte del programa
        print("Contraseña guardada exitosamente.")
    elif respuesta == "no":
        print("La contraseña no fue guardada.")
    else:
        print("Respuesta no válida. La contraseña no fue guardada.")



def ver_contraseñas():
    print("Función para ver contraseñas guardadas")

